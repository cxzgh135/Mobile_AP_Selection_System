﻿var net = require('net');
var express = require('express');// Express 모듈
var app = express(); // Express 모듈
var requestIP = require('request-ip');
var fs = require('fs');
var bodyParser = require('body-parser');
var connectedSockets= new Set();
var sleep = require('system-sleep');





var receiveLSTMArray = new Set();
var socketMap = new Set();


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

// 필요변수들 정의
var UserInfo = [{'DeviceName':'Lee','Priority':'1'},{'DeviceName':'Jeong','Priority':'3'},{'DeviceName':'Jo','Priority':'2'}];
var dataTraffic  = 0;
var socketsetPassword = 'khunet.net';
var socketsetCapacity = 'WPA';
var dataPriority = 0;
var LSTMTraffic = 0 ;
var maxTraffic = 2000;
var result = {
  'SSID':'',
  'capacity':'WPA',
  'password':'khunet.net'
}
var socketset;
var lowest=987654321;
var i =0;
  var item;
  var userPriority = 1;



var solveResult=function(dataTraffic, dataPriority,connectedSockets){
  for(let data of connectedSockets){
   if(data.PredictTraffic == lowest){
    item = data;
   }
  }
  console.log('solving Result');
  if(lowest > maxTraffic){
    var jsontrafficdata2 = JSON.stringify({'type':2,'order':'sudo hostapd_cli all_sta','dataPriority':dataPriority});
    item.socketset.write(jsontrafficdata2);
    console.log('sended to', item.SSID, 'command !' );
  }
  else{
  }
}


// socket
var server = net.createServer(function(socket){
  socketset = socket;
  app.post('/pass', function(request,response){
    console.log('User IP : ', requestIP.getClientIp(request),' Executed pass');
    // test Code ( Request Data Set )
    dataTraffic  = request.body.Traffic;
    dataPriority=  userPriority;
    lowest=987654321;
    // 입력받은 request 를 JSON 으로 패키징
    var jsontrafficdata = JSON.stringify({'type':1,'traffic':dataTraffic,'priority':dataPriority});
    console.log('User Traffic : ', dataTraffic, ' User Priority : ', dataPriority);
//연결되어 있는 모든 소켓에 명령어 전송
     for(let item2 of connectedSockets){
      if(item2 == undefined) continue;
       item2.socketset.write(jsontrafficdata);


	}


    setTimeout(function(){
    solveResult(dataTraffic,dataPriority,connectedSockets);
   },1000);

  sleep(5000);
   setTimeout(function(){
     var responsejson = JSON.stringify({'SSID':item.SSID,'Password':item.Password,'Capacity':item.Capacity});
     console.log(responsejson);
      response.send(responsejson);
   },2000);
  });



// client에서 완료된 LSTM DATA 를 표시해주는 함수
  socket.on('data', function(data){

    var receivedData = JSON.parse(data);
    switch(receivedData.type){
      case 1:
      console.log(receivedData.data);
      var APinfo =new Object();
      var receive2 = JSON.parse(receivedData.data);
      APinfo.SSID = receive2.SSID;
      APinfo.socketset = socketset;
      APinfo.Capacity = socketsetCapacity;
      APinfo.Password = socketsetPassword;
      connectedSockets.add(APinfo);
      break;

      case 2:
      var receive3ssid =receivedData.SSID;
      var receive3traffic = receivedData.PredictTraffic;
      var predictSSID = receive3ssid;
      for(let item of connectedSockets){
        if(item.SSID == receive3ssid){
          item.PredictTraffic = receive3traffic;
        }
         if(lowest > item.PredictTraffic){
      lowest = item.PredictTraffic;
      console.log('lowest fixed:' ,lowest);
        }
     }
      break;
     }
   });
});


server.on('connection',(socket)=>{
  socketset = socket;
})
// 에러함수
server.on('error', function(err){
  console.log('err' , err);
});
// NET SOCKET 서버 구동
server.listen(5000,function(){
  console.log('listening on 5000..');
});
app.listen(3000);
console.log('HTTP Server is stared at  3000  PORT.');



// TEST /POST FORM
app.get('/',function(request,response){
     fs.createReadStream("./example.html").pipe(response); // 같은 디렉토리에 있는 index.html를 response 함
});

// http 서버구동
