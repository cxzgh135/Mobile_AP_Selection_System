package khu.uclab.lhg.wificonnector;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class Adapter extends FragmentPagerAdapter {
    private static final int MAX_PAGE = 2;
    Fragment cur_fragment = new Fragment();

    public Adapter(FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    @Override
    public Fragment getItem(int pos) {
        if(pos < 0 || MAX_PAGE <= pos)
            return null;
        switch (pos) {
            case 0:
                cur_fragment = new ServiceFragment();
                break;
            case 1:
                cur_fragment = new YoutubeFragment();
                break;
        }
        return cur_fragment;
    }

    @Override
    public int getCount() {
        return MAX_PAGE;
    }
}
