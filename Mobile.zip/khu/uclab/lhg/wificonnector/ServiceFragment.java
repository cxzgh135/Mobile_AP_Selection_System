package khu.uclab.lhg.wificonnector;

import android.app.Fragment;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class ServiceFragment extends android.support.v4.app.Fragment {

    private final static String TAG = "SERVICE FRAGMENT";
    private Messenger mServiceMessenger = null;
    private boolean mIsBound;

    Button button1, button2;
    TextView mainText;

    HttpThread httpThread = HttpThread.getInstacne();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout) inflater.inflate(R.layout.fragment_service, container, false);
        button1 = (Button) linearLayout.findViewById(R.id.button1);
        button2 = (Button) linearLayout.findViewById(R.id.button2);
        mainText = (TextView) linearLayout.findViewById(R.id.mainText);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "서비스 시작 버튼 클릭");
                Intent intent = new Intent(getActivity(), MyService.class);
                getActivity().startService(intent);
                getActivity().bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
                mIsBound = true;
                mainText.setText("Start Service");
                Handler delayHandler = new Handler();
                delayHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if(DetectYoutube()) {
                            httpThread.setFgHandler(mHandler);
                            httpThread.setValue(calcCurrentTraffic(), calcCurrentPriority());
                            httpThread.getThHandler().sendEmptyMessage(HttpThread.Type.TEST);
                            Toast.makeText(getActivity(), "Send Traffic Data to Server", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, 4000);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "서비스 종료 버튼 클릭");
                Intent intent = new Intent(getActivity(), MyService.class);
                if(mIsBound) {
                    getActivity().unbindService(mConnection);
                    mIsBound=false;
                }
                getActivity().stopService(intent);
                mainText.setText("Stop Service");
            }
        });
        return linearLayout;
    }

    private String calcCurrentTraffic() {
        return "8453215";
    }
    private String calcCurrentPriority() {
        return "1";
    }

    private boolean DetectYoutube() {
        Toast.makeText(getActivity(), "Detect Youtube play", Toast.LENGTH_SHORT).show();
        return true;
    }

    private final Messenger mMessenger = new Messenger(new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            Log.d(TAG, String.format("Msg what : %d, Msg obj : %s", msg.what, msg.obj.toString()));
            switch (msg.what) {
                case MyService.MSG_SEND_TO_ACTIVITY:
                    mainText.setText(msg.getData().getString("fromService"));
                    break;
            }
            return false;
        };
    }));

    private void sendMessageToService(String str) {
        if(mIsBound) {
            if(mServiceMessenger != null) {
                try {
                    Message msg = Message.obtain(null, MyService.MSG_SEND_TO_SERVICE, str);
                    msg.replyTo = mMessenger;
                    mServiceMessenger.send(msg);
                } catch (RemoteException e ) {
                    e.printStackTrace();
                }
            }
        }
    }

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(TAG, "onServiceConnected");
            mServiceMessenger = new Messenger(service);
            try {
                Message msg = Message.obtain(null, MyService.MSG_REGISTER_CLIENT, "MSG_REGISTER_CLIENT");
                msg.replyTo = mMessenger;
                mServiceMessenger.send(msg);
            } catch(RemoteException e) {
                e.printStackTrace();;
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if(msg.what == HttpThread.Type.ERROR) {
                Log.d(TAG, "ERROR msg: " + msg.obj.toString());
                Toast.makeText(getActivity(), "Error msg: " + msg.obj.toString(), Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                switch (msg.what) {
                    case HttpThread.Type.CONNECT:
                        Log.d(TAG, "Server msg: " + msg.obj.toString());
                        Toast.makeText(getActivity(), "Server msg: " + msg.obj.toString(), Toast.LENGTH_SHORT).show();
                        break;
                    case HttpThread.Type.TEST:
                        JSONObject jsonObject = new JSONObject(msg.obj.toString());
                        String SSID = jsonObject.getString("SSID");
                        String Password = jsonObject.getString("Password");
                        String Capacity = jsonObject.getString("Capacity");
                        mainText.setText(String.format("SSID : %s, PW : %s, Capacity : %s", SSID, Password, Capacity));
                        WifiUtil.connectWifi(SSID,Password,WifiUtil.Type.WPA);
                        Toast.makeText(getActivity(), String.format("Connect Wifi SSID : %s", SSID), Toast.LENGTH_SHORT).show();
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
}
