package khu.uclab.lhg.wificonnector;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class YoutubeFragment extends Fragment {
    private final static String TAG = "YOUTUBE FRAGMENT";
    Button connectButton;
    HttpThread httpThread = HttpThread.getInstacne();
    TextView servermsg;
    WifiManager mainWifi;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout) inflater.inflate(R.layout.fragment_youtube, container, false);
        connectButton = (Button) linearLayout.findViewById(R.id.connectButton);
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                httpThread.setFgHandler(mHandler);
                httpThread.setValue("12345","1");
                httpThread.getThHandler().sendEmptyMessage(HttpThread.Type.TEST);
            }
        });
        servermsg = (TextView) linearLayout.findViewById(R.id.servermsg);
        mainWifi = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiUtil.setWifiManager(mainWifi);
        return linearLayout;
    }

    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if(msg.what == HttpThread.Type.ERROR) {
                Log.d(TAG, "ERROR msg: " + msg.obj.toString());
                Toast.makeText(getActivity(), "Error msg: " + msg.obj.toString(), Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                switch (msg.what) {
                    case HttpThread.Type.CONNECT:
                        Log.d(TAG, "Server msg: " + msg.obj.toString());
                        Toast.makeText(getActivity(), "Server msg: " + msg.obj.toString(), Toast.LENGTH_SHORT).show();
                        break;
                    case HttpThread.Type.TEST:
                        JSONObject jsonObject = new JSONObject(msg.obj.toString());
                        String SSID = jsonObject.getString("SSID");
                        String Password = jsonObject.getString("Password");
                        String Capacity = jsonObject.getString("Capacity");
                        servermsg.setText(String.format("SSID : %s, PW : %s, Capacity : %s", SSID, Password, Capacity));
                        WifiUtil.connectWifi(SSID,Password,WifiUtil.Type.WPA);
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
}
