package khu.uclab.lhg.wificonnector;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.util.Log;

import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;
import static android.content.Context.WIFI_SERVICE;

public class WifiUtil {
    private final static String TAG = "WifiUtil";
    private static WifiManager wifiManager = null;

    public static WifiUtil instance = null;
    public static WifiUtil getInstance(Context ctx) {
        if( instance == null ) {
            instance = new WifiUtil(ctx);
        }
        return instance;
    }

    private WifiUtil(Context context) {

    }

    public static void setWifiManager(WifiManager wm) {
        wifiManager = wm;
    }

    public static void connectWifi(String ssid, String pw, int type) {
        String networkSSID = ssid;
        String networkPass = pw;

        WifiConfiguration conf = new WifiConfiguration();
        conf.SSID = "\"" + networkSSID + "\"";

        switch (type) {
            case Type.WEP:
                conf.wepKeys[0] = "\"" + networkPass + "\"";
                conf.wepTxKeyIndex = 0;
                conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
                conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
                break;
            case Type.WPA:
                conf.preSharedKey = "\""+ networkPass +"\"";
                break;
            case Type.OPEN:
                conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
                break;
        }
        int networkId = wifiManager.addNetwork(conf);
        wifiManager.disconnect();
        wifiManager.enableNetwork(networkId, true);
        wifiManager.reconnect();
    }

    public static int getNetworkInfo(Context ctx) {
        ConnectivityManager connectivityManager = (ConnectivityManager) ctx.getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if(networkInfo != null && networkInfo.isConnected()) {
            if(networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                return Type.WIFI;
            }
            else if(networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                return Type.MOBILE;
            }
        } else {
            return Type.NONETWORK;
        }
        return Type.ERROR;
    }

    public class Type {
        public final static int ERROR = -1;
        public final static int WEP = 1;
        public final static int WPA = 2;
        public final static int OPEN = 3;
        public final static int WIFI = 10;
        public final static int MOBILE = 11;
        public final static int NONETWORK = 12;
    }
}
