package khu.uclab.lhg.wificonnector;

import android.app.Service;
import android.content.Intent;
import android.net.TrafficStats;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

public class MyService extends Service {

    private final static String TAG = "MYSERVICE";
    public final static int MSG_REGISTER_CLIENT = 1;
    public final static int MSG_UNREGISTER_CLIENT = 2;
    public final static int MSG_SEND_TO_SERVICE = 3;
    public final static int MSG_SEND_TO_ACTIVITY = 4;
    private boolean flag = false;
    private long prevRxByte = 0;
    private long currentRxByte = 0;
    private Messenger mClient = null;

    @Override
    public IBinder onBind(Intent intent) {
        return mMessenger.getBinder();
    }

    private final Messenger mMessenger = new Messenger(new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            Log.d(TAG, String.format("msg what : %d, msg obj : %s", msg.what, msg.obj.toString()));
            switch (msg.what) {
                case MSG_REGISTER_CLIENT:
                    mClient = msg.replyTo;
                    break;
            }
            return false;
        }
    }));

    private void sendMsgToActivity(String str) {
        try {
            Bundle bundle = new Bundle();
            bundle.putString("fromService", str);
            Message msg = Message.obtain(null, MSG_SEND_TO_ACTIVITY, "MSG_SEND_TO_ACTIVITY");
            msg.setData(bundle);
            mClient.send(msg);
        } catch (RemoteException e ) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate() {
        Log.d(TAG, "서비스 onCreate");
        flag = true;
        runTask();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "서비스 onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        flag = false;
        Log.d(TAG, "서비스 onDestroy");
    }

    private void runTask () {
        new Handler().postDelayed(task, 1000);
    }

    private Runnable task = new Runnable() {
        @Override
        public void run() {
            //실제 동작
            long mrb = TrafficStats.getMobileRxBytes();
            long mrp = TrafficStats.getMobileRxPackets();
            long mtb = TrafficStats.getMobileTxBytes();
            long mtp = TrafficStats.getMobileTxPackets();
            long trb = TrafficStats.getTotalRxBytes();
            long trp = TrafficStats.getTotalRxPackets();
            long ttb = TrafficStats.getTotalTxBytes();
            long ttp = TrafficStats.getTotalTxPackets();
            prevRxByte = currentRxByte;
            currentRxByte = trb;
            String str = String.format(
                    "\nMobile RxBytes : %d\n" +
                     "Mobile RxPackets : %d\n" +
                     "Mobile TxBytes : %d\n" +
                     "Mobile TxPackets : %d\n" +
                     "Mobile Total RxBytes : %d\n" +
                     "Mobile Total RxPackets : %d\n" +
                     "Mobile Total TxBytes : %d\n" +
                     "Mobile Total TxPackets : %d\n" +
                     "RxByte for 1sec : %d"
                    , mrb,mrp,mtb,mtp,trb,trp,ttb,ttp,  currentRxByte - prevRxByte
            );
            Log.d(TAG, str);
            sendMsgToActivity(str);
            if(flag)
                runTask();
        }
    };
}
