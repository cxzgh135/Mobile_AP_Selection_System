package khu.uclab.lhg.wificonnector;

/**
 * Created by LeeHyunGyu on 2018-04-12.
 */

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class HttpThread extends Thread {

    private static HttpThread instance = null;
    private HttpThread() {}
    public static HttpThread getInstacne() {
        if(instance == null) {
            instance = new HttpThread();
            instance.setDaemon(true);
            instance.start();
        }
        return instance;
    }

    final private String TAG = "HttpThread";
    final private String callback_url = "http://163.180.173.83:3000/pass";
    private String priority = "";
    private String traffic = "";

    private Handler thHandler = null; // 쓰레드 핸들러
    private Handler fgHandler = null; // 프래그먼트 핸들러
    private String myResult = "";

    public Handler getThHandler() {
        return thHandler;
    }

    public void setFgHandler(Handler fgHandler) {
        this.fgHandler = fgHandler;
    }

    public void setValue(String traffic, String priority) {
        this.traffic = traffic;
        this.priority = priority;
    }

    //====================================================================================================

    @Override
    public void run() {
        Looper.prepare();
        thHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                Message retMsg = new Message();
                switch (msg.what) {
                    case Type.CONNECT:
                        try {
                            URL url = new URL(callback_url + "Traffic=" + traffic + "&Priority=" + priority);
                            HttpURLConnection http = (HttpURLConnection) url.openConnection();

                            InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                            BufferedReader reader = new BufferedReader(tmp);
                            StringBuilder builder = new StringBuilder();
                            String str;
                            while ((str = reader.readLine()) != null) {
                                builder.append(str);
                                Log.d(TAG, str);
                            }
                            myResult = builder.toString();
                            retMsg.obj = myResult;
                            retMsg.what = Type.CONNECT;
                            fgHandler.sendMessage(retMsg);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case Type.TEST:
                        try {
                            Log.d(TAG, callback_url.toString());
                            URL url = new URL(callback_url);
                            HttpURLConnection http = (HttpURLConnection) url.openConnection();

                            http.setDefaultUseCaches(false);
                            http.setDoInput(true);
                            http.setDoOutput(true);
                            http.setRequestMethod("POST");

                            http.setRequestProperty("content-type", "application/json");

                            JSONObject jsonObject = new JSONObject();
                            try {
                                jsonObject.put("Priority", priority);
                                jsonObject.put("Traffic", traffic);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            Log.d(TAG, jsonObject.toString());
                            OutputStreamWriter outStream = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                            PrintWriter writer = new PrintWriter(outStream);
                            writer.write(jsonObject.toString());
                            writer.flush();

                            InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                            BufferedReader reader = new BufferedReader(tmp);
                            StringBuilder builder = new StringBuilder();
                            String str;
                            while ((str = reader.readLine()) != null) {
                                builder.append(str);
                                Log.d(TAG, str);
                            }
                            myResult = builder.toString();
                            retMsg.obj = myResult;
                            retMsg.what = Type.TEST;
                            fgHandler.sendMessage(retMsg);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                }
            }
        };
        Looper.loop();
    }

    public static class Type {
        public static final int ERROR = -1;
        public static final int CONNECT = 1;
        public static final int TEST = 2;
    }
}
