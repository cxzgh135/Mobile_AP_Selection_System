﻿var net = require('net');
var PythonShell = require('python-shell'); // Python-Shell, nodejs에서 python을 실행시키는 모듈
var sleep = require('system-sleep');
var exec = require('child_process').exec;




var APSSID = 'raspberry1';
var APPassword = 'khunet.net';
var PriorityList = [{Device:'50:77:05:e5:3a:f6',Priority:5}]
var APCapacity = 'WPA';





var Trafficdata = 0;
var Priority = 0;
var dataReceivedFromLSTM = 0;
var socket = net.connect({host:'192.168.0.240',port:5000},function(){
  console.log('client Start!');
  var data = JSON.stringify({ 'type' : 1,'data' : JSON.stringify({'SSID':APSSID,'Password':APPassword}) });
  socket.write(data)
});
socket.on('data',function(data){
  var receivedata = JSON.parse(data);
  switch(receivedata.type){
    case 1:
  Trafficdata = receivedata.traffic;
  Priority = receivedata.priority;
  console.log('receive Traffic : ',Trafficdata,'receive Priority : ', Priority);
  var options = {
    mode:'text',
    pythonPath:'', // Window path
    pythonOptions:['-u'],
    // 실행항 .py 파일의경로, app.js 파일과 같은 경로에 있을 경우 생략 / 아닐시 작성
    // scariptPath:
    args:[Trafficdata,Priority]
  };
  // python 파일 실행 후 print
    console.log('started python shell');
PythonShell.PythonShell.run("predict.py", options, function(err,result){
    if(err) throw err;
    console.log('finished python shell', result);
  // String to int
    result *=1;
    dataReceivedFromLSTM = result;
// result 파일을 받아 json parsing 을 통해 데이터 분석 후 변수에 저장
    console.log('Receive data from python : ' ,dataReceivedFromLSTM );


var APinfo = JSON.stringify({'type' :2,'SSID':APSSID,'PredictTraffic':dataReceivedFromLSTM,'capacity':APCapacity,'password':APPassword});
	console.log(dataReceivedFromLSTM);
    socket.write(APinfo);
  });
//    sleep(30000);

	break;
    case 2:
      var option= {
        encodinf:'utf-8',
        timeout:0,
        maxBuffer:200*1024,
        killSignal:'SIGTERM',
        cwd:null,
        env:null
      };
      console.log(receivedata.order);

      exec(receivedata.order,function(error,stdout,stderr){
        console.log('stdout : ', stdout);

      });
	var datanum = 'sudo hostapd_cli disassociate '+PriorityList.Device;
	console.log('disconnect ',datanum);
	exec(datanum,function(error,stdout,stderr){
		console.log('stdout: ', stdout);
	});
	break;
	}
});
socket.on('connect', function(){
  console.log('connected to server');
});



console.log('client Start!');
