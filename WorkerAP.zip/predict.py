from keras.engine.saving import load_model
import numpy as np
from util import pre_processing, create_dataset
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import math
from sklearn.preprocessing import MinMaxScaler
model = load_model('./model/new_model5.h5')
csv = pre_processing('./train.csv')
sc = MinMaxScaler((0,1))
csv = sc.fit_transform(csv)
test_x, test_y = create_dataset(csv, 10)
pred = model.predict(test_x)


plt.plot(pred,'ro',label='predict')
plt.plot(test_y,'bo', label='Actual')
plt.legend()
plt.savefig('predict.png')
