import pandas as pd
import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import CuDNNLSTM
from keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard
from util import pre_processing, create_dataset
from sklearn.preprocessing import MinMaxScaler
from keras.optimizers import RMSprop

model_path = './model/model5.h5'
seq_len = 500
train = pre_processing('./train_not.csv')
test = pre_processing('./test_not.csv')

train_x, train_y = create_dataset(train,seq_len)
test_x, test_y = create_dataset(test,seq_len)

train_x = np.reshape(train_x, (train_x.shape[0],train_x.shape[1],  1)) 
test_x = np.reshape(test_x, (test_x.shape[0],test_x.shape[1],1))

model = Sequential()
model.add(CuDNNLSTM(64, input_shape = (seq_len,1)))
model.add(Dense(1))
model.compile(loss = 'mae', optimizer = 'adam')
cb_checkpoint = ModelCheckpoint(filepath=model_path, monitor='loss', verbose=1, save_best_only=True)
cb_early_stopping = EarlyStopping(monitor='loss', patience=3)
model.fit(train_x,train_y, epochs=100, batch_size = 2048, callbacks=[cb_checkpoint, cb_early_stopping]) 

pred = model.predict(test_x)
print(pred)


