import pandas as pd
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.layers import CuDNNLSTM, LSTM
from keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard
from util import pre_processing, create_dataset
from sklearn.preprocessing import MinMaxScaler
from keras.optimizers import RMSprop
import matplotlib.pyplot as plt
model_path = './model/new_model5.h5'
seq_len = 10
train = pre_processing('./train.csv')
test = pre_processing('./test.csv')
sc_test = MinMaxScaler((0,1))
sc_train = MinMaxScaler((0,1))

train = sc_train.fit_transform(train)
test = sc_test.fit_transform(test)

train_x, train_y = create_dataset(train,seq_len)
test_x, test_y = create_dataset(test,seq_len)

train_x = np.reshape(train_x, (train_x.shape[0],train_x.shape[1], 1 )) 
test_x = np.reshape(test_x, (test_x.shape[0],test_x.shape[1],1))

model = Sequential()
model.add(CuDNNLSTM(128,return_sequences = True, input_shape = (seq_len,1)))
model.add(Dropout(0.2))
model.add(CuDNNLSTM(128))
model.add(Dropout(0.2))
model.add(Dense(1))
model.compile(loss = 'mse', optimizer = 'adam')
cb_checkpoint = ModelCheckpoint(filepath=model_path, monitor='loss', verbose=1, save_best_only=True)
cb_early_stopping = EarlyStopping(monitor='loss', patience=3)
model.fit(train_x , train_y, epochs=100, batch_size = 2048, callbacks=[cb_checkpoint, cb_early_stopping]) 

pred = model.predict(test_x,batch_size = 2048)
pred = sc_train.inverse_transform(pred)
test_y = sc_test.inverse_transform(test_y)
for i in range(len(pred)):
    print("actual : {} pred : {} ".format(test_y[i],pred[i]))
print((sum(test_y)-sum(pred))/len(pred))
plot_x = np.arange(len(pred))
plt.plot(plot_x, test_y, 'ro', label='Actual')
plt.plot(plot_x, pred, 'bo', label='predict')
plt.legend()
plt.savefig('result.png')


