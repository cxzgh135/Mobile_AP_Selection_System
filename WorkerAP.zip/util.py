import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from scipy.ndimage.filters import gaussian_filter
from scipy.signal import medfilt, savgol_filter
def create_dataset(data_raw, seq_len):
    dataX,dataY = [], []
    for index in range(len(data_raw) - seq_len):
        dataX.append(data_raw[index : index+seq_len])
        dataY.append(data_raw[index+seq_len])
    return np.array(dataX), np.array(dataY)



def pre_processing(data_path):
    df = pd.read_csv(data_path)
    #convert = lambda a : a[0:11]
    #convert_two = lambda a : '0'+a if len(a)==1 else a
    
    #df['Time']= pd.to_datetime(df['Date'].map(str).map(convert)+df['Hour'].map(str).map(convert_two)+":00")
    df=df.drop(['Hour','CellName'], axis=1)
    #df=df.set_index('Time')
    df=df.set_index('Date')
    #arr = df.values
    arr = np.concatenate(df.values, axis=None)
    arr = gaussian_filter(arr, 2)
    #arr = savgol_filter(arr,9, 5)
    #arr = medfilt(arr,3)
    arr = np.array_split(arr,len(arr))
    return arr



if __name__ == "__main__":
    pre_processing('train.csv')
